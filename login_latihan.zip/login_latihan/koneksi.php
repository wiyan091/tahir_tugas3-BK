<?php
$server = "localhost";
$user = "root";
$pass = "";
$db = "login_latihan";
$conn = mysqli_connect($server, $user, $pass, $db);
if (!$conn) {
    die("Koneksi ke database gagal: " . mysqli_connect_error());
}
?>