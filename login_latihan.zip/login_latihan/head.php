<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" />
    <!-- icon -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" />
    <title>Menu Utama</title>
</head>
<style>
    .bg-purple {
        background-color: purple;
    }
</style>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-purple">
        <div class="container">
            <a class="navbar-brand" style="color: white;">Selamat Datang, <?php echo $_SESSION['username']; ?>!</a>

            <button
                class="navbar-toggler"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarNavAltMarkup"
                aria-controls="navbarNavAltMarkup"
                aria-expanded="false"
                aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link" href="./index.php">List</a>
                    <a class="nav-link" href="./create.php">Create Data</a>
                </div>
                <div class="ms-auto">
                    <form action="logout.php" method="POST">
                        <button type="submit" class="btn btn-black">
                            <i class="fas fa-sign-out-alt">Logout</i>
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </nav>
</body>

</html>