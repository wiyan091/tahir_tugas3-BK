<?php
session_start();
include('head.php');
include('foot.php');
include('koneksi.php');

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit(); // Terminate script execution after the redirect
}

function getAllUser($conn)
{
    $sql = "SELECT * FROM data_mahasiswa";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        return mysqli_fetch_all($result, MYSQLI_ASSOC);
    } else {
        return [];
    }
}
?>
<div class="container py-4">
    <div class="table-responsive">
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>ID</th>
                    <th>Nama Mahasiswa</th>
                    <th>SKS</th>
                    <th>IPK</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $data_mahasiswas = getAllUser($conn);
                $i = 1;
                ?>
                <?php if (!empty($data_mahasiswas)) : ?>
                    <?php foreach ($data_mahasiswas as $data_mahasiswa) : ?>
                        <tr>
                            <td><?= $i++ ?></td>
                            <td><?= htmlspecialchars($data_mahasiswa['id']) ?></td>
                            <td><?= htmlspecialchars($data_mahasiswa['nama']) ?></td>
                            <td><?= htmlspecialchars($data_mahasiswa['sks']) ?></td>
                            <td><?= htmlspecialchars($data_mahasiswa['ipk']) ?></td>
                            <td>
                                <a href="./update_user.php?id=<?= $data_mahasiswa['id'] ?>" class="btn btn-sm btn-success">Update</a>
                                <a href="./delete_user.php?id=<?= $data_mahasiswa['id'] ?>" class="btn btn-sm btn-danger">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else : ?>
                    <tr>
                        <td colspan="6" class="text-center">Tidak ada data</td> <!-- Sesuaikan jumlah kolom dengan colspan -->
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php
include('foot.php');
?>
