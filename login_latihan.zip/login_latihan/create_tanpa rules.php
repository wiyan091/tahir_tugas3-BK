<?php
session_start();
include('head.php');
include('foot.php');
include('koneksi.php');

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit(); // Terminate script execution after the redirect
}

$errors = []; // varioabel yang akan digunakan untuk menampung pesan error validasi

// script kode ini hanya akan dieksekusi jika kita melakukan submit form
if (!empty($_POST)) {

    // ambil data yang dikirimkan melalui form dan simpan ke dalam variabel
    $nama = $_POST['nama'];
    $sks = $_POST['sks'];
    $ipk = $_POST['ipk'];

    // lakukan validasi untuk tiap inputan, jika inputan kosong maka tambahkan pesan error kedalam variabel $errors
    if ($nama == "") {
        $errors['nama'] = "Nama tidak boleh kosong";
    }
    if ($sks == "") {
        $errors['sks'] = "SKS tidak boleh kosong";
    }
    if ($ipk == "") {
        $errors['ipk'] = "IPK tidak boleh kosong";
    }
    // cek jika tidak ada error maka lakukan proses penyimpanan data
    if (!$errors) {
        // buat sql
        $sql = "INSERT INTO data_mahasiswa (nama, sks, ipk) VALUES ('$nama', '$sks', '$ipk')";
        // simpan data
        if (mysqli_query($conn, $sql)) {
            // berhasil
            echo "<script>alert('Data berhasil disimpan');</script>";
            echo "<meta http-equiv='refresh' content='0; url=index.php'>";
        } else {
            // gagal
            echo "<script>alert('Gagal menyimpan data');</script>";
            echo "<meta http-equiv='refresh' content='0; url=index.php'>";
        }
    }
}

?>

<!DOCTYPE html>
<div class="container py-5">
    <h2>Tambah Data User</h2>
    <?php foreach ($errors as $error) : ?>
        <div class="alert bg-danger" role="alert">
            <?= $error ?>
        </div>
    <?php endforeach; ?>
    <form class="mt-4" method="POST">
        <div class="mb-3">
            <label for="nama" class="form-label">Nama</label>
            <input name="nama" type="text" class="form-control" id="nama" />
        </div>
        <div class="mb-3">
            <label for="sks" class="form-label">SKS</label>
            <input name="sks" type="number" class="form-control" id="sks" />
        </div>
        <div class="mb-3">
            <label for="ipk" class="ipk">IPK</label>
            <input name="ipk" type="number" step="0.01" class="form-control" id="ipk" />
        </div>
        <button type="submit" class="btn btn-success">Simpan</button>
    </form>
</div>

</body>

</html>