<?php
session_start();
include('head.php');
include('foot.php');
include('koneksi.php');

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit(); // Terminate script execution after the redirect
}


// Cek jika ada ID di URL
if (!empty($_GET) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $id = mysqli_real_escape_string($conn, $id); // Melindungi dari SQL Injection
    $sql = "SELECT * FROM data_mahasiswa WHERE id='$id'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $data_mahasiswa = mysqli_fetch_assoc($result);
    } else {
        header('Location: ./index.php');
        exit();
    }
} else {
    header('Location: ./index.php');
    exit();
}

// Script kode ini hanya akan dieksekusi jika kita melakukan submit form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $id = mysqli_real_escape_string($conn, $id); // Melindungi dari SQL Injection
    $sql = "DELETE FROM data_mahasiswa WHERE id='$id'";

    // Hapus data
    if (mysqli_query($conn, $sql)) {
        // Berhasil
        echo "<script>alert('Data berhasil Dihapus');</script>";
        echo "<meta http-equiv='refresh' content='0; url=index.php'>";
    } else {
        // Gagal
        echo "<script>alert('Gagal menghapus data');</script>";
        echo "<meta http-equiv='refresh' content='0; url=index.php'>";
    }
}
?>
<div class="container d-flex flex-column justify-content-center align-items-center py-4 text-center">
    <h4>Hapus data Mahasiswa berikut ini?</h4>
    <br>
    <div>Nama Mahasiswa: <?= ($data_mahasiswa['nama']) ?></div>
    <div>SKS: <?= ($data_mahasiswa['sks']) ?></div>
    <div>IPK: <?= ($data_mahasiswa['ipk']) ?></div>
    <br>
    <form method="POST">
        <input type="hidden" name="id" value="<?= ($data_mahasiswa['id']) ?>">
        <button type="submit" class="btn btn-success">OK</button>
        <a href="./index.php" class="btn btn-danger">BATAL</a>
    </form>
</div>

<?php
include('foot.php');
?>