<?php
session_start();
include('head.php');
include('foot.php');
include('koneksi.php');

// Fungsi untuk memeriksa ketersediaan nama
function isNameAvailable($conn, $nama, $id)
{
    $sql = "SELECT nama FROM data_mahasiswa WHERE nama='$nama' AND id != '$id'";
    $result = mysqli_query($conn, $sql);
    return mysqli_num_rows($result) == 0;
}

$errors = []; // variabel yang akan digunakan untuk menampung pesan error validasi
$data_mahasiswa = []; // variabel untuk menyimpan data user

// Cek jika ada ID di URL untuk mengupdate data
if (!empty($_GET) && isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM data_mahasiswa WHERE id='$id'";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        $data_mahasiswa = mysqli_fetch_assoc($result);
    } else {
        header('Location: ./index.php');
        exit();
    }
}

// Script kode ini hanya akan dieksekusi jika kita melakukan submit form
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data yang dikirimkan melalui form dan simpan ke dalam variabel
    $nama = $_POST['nama'];
    $sks = $_POST['sks'];
    $ipk = $_POST['ipk'];

    // Lakukan validasi untuk tiap inputan, jika inputan kosong maka tambahkan pesan error ke dalam variabel $errors
    if (empty($nama)) {
        $errors['nama'] = "Nama tidak boleh kosong";
    }
    if (empty($sks)) {
        $errors['sks'] = "SKS tidak boleh kosong";
    }
    if (empty($ipk)) {
        $errors['ipk'] = "IPK tidak boleh kosong";
    }

    // Cek jika tidak ada error maka lakukan proses penyimpanan data
    if (empty($errors)) {
        // Cek duplikasi data
        if (isNameAvailable($conn, $nama, $id)) {
            // Buat SQL untuk update data
            $sql = "UPDATE data_mahasiswa SET nama='$nama', sks='$sks', ipk='$ipk' WHERE id='$id'";
            // Simpan data
            if (mysqli_query($conn, $sql)) {
                // Berhasil
                echo "<script>alert('Data berhasil disimpan');</script>";
                echo "<meta http-equiv='refresh' content='0; url=index.php'>";
            } else {
                // Gagal
                echo "<script>alert('Gagal menyimpan data');</script>";
                echo "<meta http-equiv='refresh' content='0; url=index.php'>";
            }
        } else {
            $errors['nama'] = "Nama $nama sudah digunakan";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data User</title>
    <!-- Include your CSS/Bootstrap here -->
</head>
<body>
    <div class="container py-5">
        <h2>Tambah Data User</h2>
        <?php foreach ($errors as $error) : ?>
            <div class="alert bg-danger" role="alert">
                <?=($error) ?>
            </div>
        <?php endforeach; ?>
        <form class="mt-4" method="POST">
            <div class="mb-3">
                <label for="nama" class="form-label">Nama Mahasiswa</label>
                <input name="nama" type="text" class="form-control" id="nama" value="<?= ($data_mahasiswa['nama'] ?? '') ?>" />
            </div>
            <div class="mb-3">
                <label for="sks" class="form-label">SKS</label>
                <input name="sks" type="number" class="form-control" id="sks" value="<?= ($data_mahasiswa['sks'] ?? '') ?>" />
            </div>
            <div class="mb-3">
                <label for="ipk" class="form-label">IPK</label>
                <input name="ipk" type="number" step="0.01" class="form-control" id="ipk" value="<?= ($data_mahasiswa['ipk'] ?? '') ?>" />
            </div>
            <button type="submit" class="btn btn-success">Simpan</button>
        </form>
    </div>
    <?php include('foot.php'); ?>
</body>
</html>
